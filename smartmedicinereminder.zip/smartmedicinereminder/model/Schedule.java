package model;

import java.time.LocalTime;
import java.util.List;
import java.util.Map;

public class Schedule {
    private User user;

    public Schedule(User user) {
        this.user = user;
    }

    public void showSchedule() {
        System.out.println("\n📋 Medicine Schedule for " + user.getName() + ":");
        List<Medicine> meds = user.getMedicines();

        if (meds.isEmpty()) {
            System.out.println("No medicines added yet.");
        } else {
            for (Medicine med : meds) {
                System.out.println(med.toString());
            }
        }
    }

    // 🆕 Show doses due now (within +-15 min)
    public void showDueNow() {
        System.out.println("\n⏰ Doses Due Now:");
        LocalTime now = LocalTime.now();
        boolean found = false;

        for (Medicine med : user.getMedicines()) {
            for (Map.Entry<LocalTime, Boolean> entry : med.getTodayDoses().entrySet()) {
                LocalTime doseTime = entry.getKey();
                boolean taken = entry.getValue();

                if (!taken && isWithinTimeWindow(now, doseTime, 15)) {
                    System.out.println("- " + med.getName() + " at " + doseTime + " [" + med.getDosage() + "]");
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("✅ No doses due right now!");
        }
    }

    private boolean isWithinTimeWindow(LocalTime now, LocalTime target, int minutes) {
        return Math.abs(now.toSecondOfDay() - target.toSecondOfDay()) <= minutes * 60;
    }
}
