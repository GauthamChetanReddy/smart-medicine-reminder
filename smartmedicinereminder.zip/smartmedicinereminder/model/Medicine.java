package model;

import java.time.LocalTime;
import java.util.*;

public class Medicine {
    private String name;
    private String dosage;
    private List<LocalTime> times;
    private int duration;
    private Map<LocalTime, Boolean> statusMap = new HashMap<>();

    // ✅ Constructor with duration
    public Medicine(String name, String dosage, List<LocalTime> times, int duration) {
        this.name = name;
        this.dosage = dosage;
        this.times = times;
        this.duration = duration;
        for (LocalTime t : times) {
            statusMap.put(t, false); // default to not taken
        }
    }

    public String getName() {
        return name;
    }

    public String getDosage() {
        return dosage;
    }

    public List<LocalTime> getTimes() {
        return times;
    }

    public int getDuration() {
        return duration;
    }

    public Map<LocalTime, Boolean> getStatusMap() {
        return statusMap;
    }

    // ✅ Mark a dose as taken or missed
    public void markDose(LocalTime time, boolean taken) {
        statusMap.put(time, taken);
    }

    // ✅ Return today's doses (up to now)
    public Map<LocalTime, Boolean> getTodayDoses() {
        Map<LocalTime, Boolean> todayDoses = new LinkedHashMap<>();
        LocalTime now = LocalTime.now();

        for (LocalTime t : times) {
            if (!t.isAfter(now)) {
                boolean status = statusMap.getOrDefault(t, false);
                todayDoses.put(t, status);
            }
        }

        return todayDoses;
    }
}
