package model;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String name;
    private int age;
    private List<Medicine> medicines;

    public User(String name, int age) {
        this.name = name;
        this.age = age;
        this.medicines = new ArrayList<>();
    }

    public void addMedicine(Medicine med) {
        medicines.add(med);
    }

    public List<Medicine> getMedicines() {
        return medicines;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
