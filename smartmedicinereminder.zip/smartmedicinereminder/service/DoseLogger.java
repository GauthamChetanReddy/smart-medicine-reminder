package service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

public class DoseLogger {
    private static final String LOG_FILE = "dose_log.txt";

    public static void logDose(String user, String medName, LocalTime time, boolean taken) {
        String status = taken ? "Taken" : "Missed";
        String entry = String.format("[%s] %s - %s at %s -> %s",
                LocalDate.now(), user, medName, time, status);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            writer.write(entry);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("❌ Error writing to log file: " + e.getMessage());
        }
    }
}
