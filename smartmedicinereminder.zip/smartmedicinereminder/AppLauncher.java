import model.User;
import model.Medicine;
import model.Schedule;
import service.DoseLogger;

import java.time.LocalTime;
import java.util.*;

public class AppLauncher {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter user name: ");
        String name = sc.nextLine();
        System.out.print("Enter age: ");
        int age = sc.nextInt();
        sc.nextLine(); // consume newline

        User user = new User(name, age);
        Schedule schedule = new Schedule(user);

        while (true) {
            System.out.println("\n==== Smart Medicine Reminder ====");
            System.out.println("1. Add Medicine");
            System.out.println("2. Show Schedule");
            System.out.println("3. Show Doses Due Now");
            System.out.println("4. Mark Dose as Taken");
            System.out.println("5. Mark Dose as Missed");
            System.out.println("6. View Dose History");
            System.out.println("7. Reset Today's Doses");
            System.out.println("8. Exit");
            System.out.println("9. View Compliance Summary Report");
            System.out.println("10. Export Compliance Report to CSV");

            System.out.print("Choose: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Medicine Name: ");
                    String medName = sc.nextLine();

                    System.out.print("Dosage (e.g., 1 tablet): ");
                    String dosage = sc.nextLine();

                    System.out.print("How many times per day? ");
                    int times = sc.nextInt();
                    sc.nextLine();

                    List<LocalTime> timeList = new ArrayList<>();
                    for (int i = 1; i <= times; i++) {
                        System.out.print("Enter time " + i + " (HH:MM): ");
                        String timeStr = sc.nextLine();
                        timeList.add(LocalTime.parse(timeStr));
                    }

                    System.out.print("For how many days? ");
                    int duration = sc.nextInt();
                    sc.nextLine();

                    Medicine med = new Medicine(medName, dosage, timeList, duration);
                    user.addMedicine(med);
                    System.out.println("✅ Medicine added!");
                    break;

                case 2:
                    schedule.showSchedule();
                    break;

                case 3:
                    schedule.showDueNow();
                    break;

                case 4:
                    System.out.print("Enter Medicine Name: ");
                    String markMedName = sc.nextLine();

                    System.out.print("Enter Time (HH:MM): ");
                    String timeStr = sc.nextLine();
                    LocalTime markTime = LocalTime.parse(timeStr);

                    boolean found = false;
                    for (Medicine m : user.getMedicines()) {
                        if (m.getName().equalsIgnoreCase(markMedName)) {
                            m.markDose(markTime, true);
                            DoseLogger.logDose(user.getName(), m.getName(), markTime, true);
                            System.out.println("✅ Dose marked as Taken & logged!");
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        System.out.println("❌ Medicine not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter Medicine Name: ");
                    String missedMed = sc.nextLine();

                    System.out.print("Enter Time (HH:MM): ");
                    String missedTimeStr = sc.nextLine();
                    LocalTime missedTime = LocalTime.parse(missedTimeStr);

                    boolean isFound = false;
                    for (Medicine m : user.getMedicines()) {
                        if (m.getName().equalsIgnoreCase(missedMed)) {
                            m.markDose(missedTime, false);
                            DoseLogger.logDose(user.getName(), m.getName(), missedTime, false);
                            System.out.println("⚠️ Dose marked as Missed & logged.");
                            isFound = true;
                            break;
                        }
                    }

                    if (!isFound) {
                        System.out.println("❌ Medicine not found.");
                    }
                    break;

                case 6:
                    try (Scanner fileScanner = new Scanner(new java.io.File("dose_log.txt"))) {
                        System.out.println("\n📜 Dose History:");
                        while (fileScanner.hasNextLine()) {
                            System.out.println(fileScanner.nextLine());
                        }
                    } catch (Exception e) {
                        System.out.println("❌ No dose history found.");
                    }
                    break;

                case 7:
                    for (Medicine m : user.getMedicines()) {
                        m.resetTodayDoses();
                    }
                    System.out.println("🔄 All today's doses have been reset.");
                    break;

                case 8:
                    System.out.println("Exiting... Stay healthy! 💊");
                    return;

                case 9:
                    generateComplianceReport(user.getName());
                    break;

                case 10:
                    exportComplianceReport(user.getName());
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // 🔍 Show compliance in terminal
    public static void generateComplianceReport(String userName) {
        try (Scanner reader = new Scanner(new java.io.File("dose_log.txt"))) {
            Map<String, int[]> report = new HashMap<>();
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (!line.contains(userName)) continue;

                String[] parts = line.split(" - ");
                if (parts.length < 2) continue;

                String medPart = parts[1];
                String[] medTokens = medPart.split(" at ");
                String medName = medTokens[0].trim();

                String status = line.contains("Taken") ? "Taken" : "Missed";

                report.putIfAbsent(medName, new int[2]);
                if (status.equals("Taken")) {
                    report.get(medName)[0]++;
                } else {
                    report.get(medName)[1]++;
                }
            }

            System.out.println("\n📊 Medicine Compliance Report:");
            System.out.println("Medicine\tTaken\tMissed\tCompliance %");
            for (String med : report.keySet()) {
                int[] stats = report.get(med);
                int total = stats[0] + stats[1];
                double percent = total == 0 ? 0 : ((double) stats[0] / total) * 100;
                System.out.printf("%-12s\t%d\t%d\t%.2f%%\n", med, stats[0], stats[1], percent);
            }

        } catch (Exception e) {
            System.out.println("❌ Error reading dose_log.txt: " + e.getMessage());
        }
    }

    // 📤 Export to CSV file
    public static void exportComplianceReport(String userName) {
        try (Scanner reader = new Scanner(new java.io.File("dose_log.txt"));
             java.io.PrintWriter writer = new java.io.PrintWriter("compliance_report.csv")) {

            Map<String, int[]> report = new HashMap<>();

            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (!line.contains(userName)) continue;

                String[] parts = line.split(" - ");
                if (parts.length < 2) continue;

                String medPart = parts[1];
                String[] medTokens = medPart.split(" at ");
                String medName = medTokens[0].trim();

                String status = line.contains("Taken") ? "Taken" : "Missed";

                report.putIfAbsent(medName, new int[2]);
                if (status.equals("Taken")) {
                    report.get(medName)[0]++;
                } else {
                    report.get(medName)[1]++;
                }
            }

            writer.println("Medicine,Taken,Missed,Compliance %");

            for (String med : report.keySet()) {
                int[] stats = report.get(med);
                int total = stats[0] + stats[1];
                double percent = total == 0 ? 0 : ((double) stats[0] / total) * 100;
                writer.printf("%s,%d,%d,%.2f%%\n", med, stats[0], stats[1], percent);
            }

            System.out.println("✅ Report exported to compliance_report.csv");

        } catch (Exception e) {
            System.out.println("❌ Error writing CSV: " + e.getMessage());
        }
    }
}
