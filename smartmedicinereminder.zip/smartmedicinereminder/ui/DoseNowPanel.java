package ui;

import model.Medicine;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

public class DoseNowPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private User user;

    public DoseNowPanel(User user) {
        this.user = user;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel heading = new JLabel("⏰ Doses Due Now");
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));

        model = new DefaultTableModel();
        model.addColumn("Medicine");
        model.addColumn("Dosage");
        model.addColumn("Scheduled Time");

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        add(heading, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void refreshData() {
        model.setRowCount(0);

        LocalTime now = LocalTime.now();
        List<Medicine> meds = user.getMedicines();

        for (Medicine med : meds) {
            for (LocalTime time : med.getTimes()) {
                if (isWithin5Minutes(now, time)) {
                    model.addRow(new Object[]{
                            med.getName(),
                            med.getDosage(),
                            time.toString()
                    });
                }
            }
        }
    }

    private boolean isWithin5Minutes(LocalTime current, LocalTime scheduled) {
        int diff = Math.abs(current.toSecondOfDay() - scheduled.toSecondOfDay());
        return diff <= 300; // 300 seconds = 5 minutes
    }
}
