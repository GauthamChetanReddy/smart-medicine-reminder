package ui;

import javax.swing.*;
import java.awt.*;

import model.User;

public class MainWindow extends JFrame {

    private CardLayout cardLayout;
    private JPanel contentPanel;

    public MainWindow() {
        setTitle("Smart Medicine Reminder 💊");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🧭 Left Menu Panel
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(8, 1, 10, 10));
        menuPanel.setBackground(new Color(200, 220, 255));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] buttons = {
                "Add Medicine", "Show Schedule", "Doses Due Now", "Mark Dose Taken",
                "Mark Dose Missed", "View History", "Compliance Report", "Export CSV"
        };

        // ✅ Dummy user for testing
        User user = new User("Reddy", 22);

        // 🧱 Right Content Panel with CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(Color.WHITE);

        // 🔌 All Panels
        MedicineFormPanel addMedPanel = new MedicineFormPanel(user);
        SchedulePanel schedulePanel = new SchedulePanel(user);
        DoseNowPanel doseNowPanel = new DoseNowPanel(user);
        MarkDosePanel markDosePanel = new MarkDosePanel(user);
        MarkMissedPanel markMissedPanel = new MarkMissedPanel(user);
        ViewHistoryPanel viewHistoryPanel = new ViewHistoryPanel();
        ComplianceReportPanel compliancePanel = new ComplianceReportPanel(user);
        ExportPanel exportPanel = new ExportPanel(user);

        // 📌 Add Panels to Content Panel
        contentPanel.add(addMedPanel, "addMedicine");
        contentPanel.add(schedulePanel, "schedule");
        contentPanel.add(doseNowPanel, "dueNow");
        contentPanel.add(markDosePanel, "markTaken");
        contentPanel.add(markMissedPanel, "markMissed");
        contentPanel.add(viewHistoryPanel, "history");
        contentPanel.add(compliancePanel, "compliance");
        contentPanel.add(exportPanel, "export");

        // ⬅️ Button Actions
        for (String label : buttons) {
            JButton btn = new JButton(label);
            btn.setFocusPainted(false);
            btn.setBackground(Color.WHITE);
            menuPanel.add(btn);

            btn.addActionListener(e -> {
                switch (label) {
                    case "Add Medicine":
                        cardLayout.show(contentPanel, "addMedicine");
                        break;
                    case "Show Schedule":
                        schedulePanel.refreshData();
                        cardLayout.show(contentPanel, "schedule");
                        break;
                    case "Doses Due Now":
                        doseNowPanel.refreshData();
                        cardLayout.show(contentPanel, "dueNow");
                        break;
                    case "Mark Dose Taken":
                        cardLayout.show(contentPanel, "markTaken");
                        break;
                    case "Mark Dose Missed":
                        cardLayout.show(contentPanel, "markMissed");
                        break;
                    case "View History":
                        cardLayout.show(contentPanel, "history");
                        break;
                    case "Compliance Report":
                        cardLayout.show(contentPanel, "compliance");
                        break;
                    case "Export CSV":
                        cardLayout.show(contentPanel, "export");
                        break;

                    default:
                        JOptionPane.showMessageDialog(this, "🚧 Feature '" + label + "' not implemented yet.");
                }
            });
        }

        // 🧩 Layout Setup
        add(menuPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainWindow().setVisible(true);
        });
    }
}
