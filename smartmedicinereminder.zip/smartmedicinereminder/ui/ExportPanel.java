package ui;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import model.User;

public class ExportPanel extends JPanel {

    private JTextArea statusArea;

    public ExportPanel(User user) {
        setLayout(new BorderLayout());

        JLabel title = new JLabel("📤 Export Compliance Report", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        statusArea = new JTextArea();
        statusArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        statusArea.setEditable(false);
        add(new JScrollPane(statusArea), BorderLayout.CENTER);

        JButton exportBtn = new JButton("📄 Export to compliance_report.csv");
        exportBtn.addActionListener(e -> exportComplianceReport(user.getName()));
        add(exportBtn, BorderLayout.SOUTH);
    }

    private void exportComplianceReport(String userName) {
        try (Scanner reader = new Scanner(new File("dose_log.txt"));
             PrintWriter writer = new PrintWriter("compliance_report.csv")) {

            Map<String, int[]> report = new LinkedHashMap<>();

            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (!line.contains(userName)) continue;

                String[] parts = line.split(" - ");
                if (parts.length < 2) continue;

                String medPart = parts[1];
                String[] medTokens = medPart.split(" at ");
                String medName = medTokens[0].trim();
                String status = line.contains("Taken") ? "Taken" : "Missed";

                report.putIfAbsent(medName, new int[2]);
                if (status.equals("Taken")) report.get(medName)[0]++;
                else report.get(medName)[1]++;
            }

            writer.println("Medicine,Taken,Missed,Compliance %");

            for (String med : report.keySet()) {
                int[] stats = report.get(med);
                int total = stats[0] + stats[1];
                double percent = total == 0 ? 0 : ((double) stats[0] / total) * 100;
                writer.printf("%s,%d,%d,%.2f%%\n", med, stats[0], stats[1], percent);
            }

            statusArea.setText("✅ Exported to compliance_report.csv");

        } catch (Exception e) {
            statusArea.setText("❌ Export failed: " + e.getMessage());
        }
    }
}
