package ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.*;
import model.User;

public class ComplianceReportPanel extends JPanel {

    private JTextArea reportArea;

    public ComplianceReportPanel(User user) {
        setLayout(new BorderLayout());

        JLabel title = new JLabel("📊 Compliance Summary Report", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        reportArea = new JTextArea();
        reportArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        reportArea.setEditable(false);
        add(new JScrollPane(reportArea), BorderLayout.CENTER);

        JButton refreshBtn = new JButton("🔁 Refresh Report");
        refreshBtn.addActionListener(e -> generateComplianceReport(user.getName()));
        add(refreshBtn, BorderLayout.SOUTH);

        // Load once on open
        generateComplianceReport(user.getName());
    }

    private void generateComplianceReport(String userName) {
        try (Scanner reader = new Scanner(new File("dose_log.txt"))) {
            Map<String, int[]> report = new LinkedHashMap<>();

            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (!line.contains(userName)) continue;

                String[] parts = line.split(" - ");
                if (parts.length < 2) continue;

                String medPart = parts[1];
                String[] medTokens = medPart.split(" at ");
                String medName = medTokens[0].trim();
                String status = line.contains("Taken") ? "Taken" : "Missed";

                report.putIfAbsent(medName, new int[2]); // [0]=Taken, [1]=Missed
                if (status.equals("Taken")) report.get(medName)[0]++;
                else report.get(medName)[1]++;
            }

            StringBuilder sb = new StringBuilder();
            sb.append("Medicine\tTaken\tMissed\tCompliance %\n");
            for (String med : report.keySet()) {
                int[] stats = report.get(med);
                int total = stats[0] + stats[1];
                double percent = total == 0 ? 0 : ((double) stats[0] / total) * 100;
                sb.append(String.format("%-12s\t%d\t%d\t%.2f%%\n", med, stats[0], stats[1], percent));
            }

            reportArea.setText(sb.toString());

        } catch (Exception e) {
            reportArea.setText("❌ Error: " + e.getMessage());
        }
    }
}
