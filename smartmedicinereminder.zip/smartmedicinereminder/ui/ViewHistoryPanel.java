package ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Scanner;

public class ViewHistoryPanel extends JPanel {

    private JTextArea historyArea;

    public ViewHistoryPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("📜 Dose History");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setHorizontalAlignment(SwingConstants.CENTER);

        historyArea = new JTextArea();
        historyArea.setEditable(false);
        historyArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        JScrollPane scrollPane = new JScrollPane(historyArea);

        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.addActionListener(e -> loadHistory());

        add(title, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(refreshBtn, BorderLayout.SOUTH);

        // Load initially
        loadHistory();
    }

    private void loadHistory() {
        historyArea.setText("");

        try (Scanner reader = new Scanner(new File("dose_log.txt"))) {
            while (reader.hasNextLine()) {
                historyArea.append(reader.nextLine() + "\n");
            }
        } catch (Exception e) {
            historyArea.setText("❌ No dose history found or error reading file.");
        }
    }
}
