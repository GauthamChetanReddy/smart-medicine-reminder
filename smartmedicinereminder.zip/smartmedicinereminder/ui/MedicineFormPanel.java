package ui;

import model.Medicine;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class MedicineFormPanel extends JPanel {
    private JTextField nameField, dosageField;
    private JSpinner daysSpinner, timesPerDaySpinner;
    private JPanel timePanel;
    private List<JComboBox<String>> timeSelectors = new ArrayList<>();

    private User user;

    public MedicineFormPanel(User user) {
        this.user = user;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel heading = new JLabel("➕ Add New Medicine");
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));

        nameField = new JTextField();
        dosageField = new JTextField();
        daysSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 365, 1));
        timesPerDaySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 6, 1));

        timesPerDaySpinner.addChangeListener(e -> updateTimeSelectors());

        form.add(new JLabel("Medicine Name:"));
        form.add(nameField);
        form.add(new JLabel("Dosage:"));
        form.add(dosageField);
        form.add(new JLabel("Duration (days):"));
        form.add(daysSpinner);
        form.add(new JLabel("Times per day:"));
        form.add(timesPerDaySpinner);

        // Time pickers
        timePanel = new JPanel(new GridLayout(0, 2, 5, 5));
        updateTimeSelectors();

        JButton addButton = new JButton("Add Medicine");
        addButton.addActionListener(e -> handleAdd());

        add(heading, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        add(timePanel, BorderLayout.EAST);
        add(addButton, BorderLayout.SOUTH);
    }

    private void updateTimeSelectors() {
        timePanel.removeAll();
        timeSelectors.clear();

        int times = (Integer) timesPerDaySpinner.getValue();

        for (int i = 0; i < times; i++) {
            JComboBox<String> box = new JComboBox<>();
            for (int h = 0; h < 24; h++) {
                for (int m = 0; m < 60; m += 30) {
                    String time = String.format("%02d:%02d", h, m);
                    box.addItem(time);
                }
            }
            timeSelectors.add(box);
            timePanel.add(new JLabel("Time " + (i + 1) + ":"));
            timePanel.add(box);
        }

        timePanel.revalidate();
        timePanel.repaint();
    }

    private void handleAdd() {
        String name = nameField.getText().trim();
        String dosage = dosageField.getText().trim();
        int duration = (Integer) daysSpinner.getValue();

        if (name.isEmpty() || dosage.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        List<LocalTime> times = new ArrayList<>();
        for (JComboBox<String> box : timeSelectors) {
            times.add(LocalTime.parse((String) box.getSelectedItem()));
        }

        Medicine med = new Medicine(name, dosage, times, duration);
        user.addMedicine(med);

        JOptionPane.showMessageDialog(this, "✅ Medicine added!");
        clearForm();
    }

    private void clearForm() {
        nameField.setText("");
        dosageField.setText("");
        daysSpinner.setValue(1);
        timesPerDaySpinner.setValue(1);
        updateTimeSelectors();
    }
}
