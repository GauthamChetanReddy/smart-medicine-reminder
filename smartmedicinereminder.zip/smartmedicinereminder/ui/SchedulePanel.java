package ui;

import model.Medicine;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class SchedulePanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private User user;

    public SchedulePanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel heading = new JLabel("📋 Medicine Schedule");
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));

        // Table model with column headers
        model = new DefaultTableModel();
        model.addColumn("Medicine");
        model.addColumn("Dosage");
        model.addColumn("Duration (days)");
        model.addColumn("Times");

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        add(heading, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    // ✅ Call this method to refresh the table whenever needed
    public void refreshData() {
        model.setRowCount(0); // Clear previous data
        List<Medicine> meds = user.getMedicines();

        for (Medicine med : meds) {
            String timeList = med.getTimes().stream()
                    .map(t -> t.toString())
                    .collect(Collectors.joining(", "));
            model.addRow(new Object[]{
                    med.getName(),
                    med.getDosage(),
                    med.getDuration(),
                    timeList
            });
        }
    }
}
