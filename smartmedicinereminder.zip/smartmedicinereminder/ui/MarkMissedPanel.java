package ui;

import model.Medicine;
import model.User;
import service.DoseLogger;

import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;

public class MarkMissedPanel extends JPanel {

    private JTextField medNameField, timeField;
    private User user;

    public MarkMissedPanel(User user) {
        this.user = user;
        setLayout(new GridLayout(5, 1, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));

        JLabel title = new JLabel("❌ Mark Dose as Missed");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setHorizontalAlignment(SwingConstants.CENTER);

        medNameField = new JTextField();
        timeField = new JTextField();

        JButton markBtn = new JButton("Mark Dose Missed");

        markBtn.addActionListener(e -> {
            String name = medNameField.getText().trim();
            String timeStr = timeField.getText().trim();

            if (name.isEmpty() || timeStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠️ Enter both medicine name and time.");
                return;
            }

            try {
                LocalTime time = LocalTime.parse(timeStr);
                boolean found = false;

                for (Medicine med : user.getMedicines()) {
                    if (med.getName().equalsIgnoreCase(name)) {
                        med.markDose(time, false); // mark as missed
                        DoseLogger.logDose(user.getName(), med.getName(), time, false);
                        JOptionPane.showMessageDialog(this, "❌ Dose marked as missed and logged.");
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    JOptionPane.showMessageDialog(this, "❌ Medicine not found.");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Invalid time format. Use HH:MM.");
            }
        });

        add(title);
        add(new JLabel("Medicine Name:"));
        add(medNameField);
        add(new JLabel("Time (HH:MM):"));
        add(timeField);
        add(markBtn);
    }
}
